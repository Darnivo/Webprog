


<?php $__env->startSection('content'); ?>
    <h1> We are skibidi warlords from liberia </h1>
    <h3> We are the best </h3>
    <img src="aris.png">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Wprog\testAnsel\projtest\resources\views/about.blade.php ENDPATH**/ ?>