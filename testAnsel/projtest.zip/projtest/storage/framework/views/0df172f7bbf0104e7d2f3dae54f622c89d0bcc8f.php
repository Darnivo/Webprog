


<?php $__env->startSection('content'); ?>
    <h1 class="text-center">Welcome to the home page</h1>
    <br>

    <div class="mx-auto" style="width: 80%;">
        <h1> this is inside </h1>

        <div class="row g-3 mt-2 mb-4" id="filterable-cards">
        <?php $__currentLoopData = $NGR; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tst): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card" style="width: 18rem;">
            <div class="card-body">
                <h5 class="card-title"><?php echo e($tst->{'Movie Name'}); ?></h5>
                <p class="card-text">Movie rating = <?php echo e($tst->Rating); ?>/5</p>
                <p class="card-text"><?php echo e($tst -> {'Release-date'}); ?></p>
            </div>
        </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Wprog\testAnsel\projtest\resources\views/home.blade.php ENDPATH**/ ?>