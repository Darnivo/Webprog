@extends('main')


@section('content')
    <h1> We are skibidi warlords from liberia </h1>
    <h3> We are the best </h3>
    <img src="aris.png">
@endsection
